package com.dhruv;
import java.util.Scanner;

public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter your PIN: ");
        String pin = scanner.nextLine();

        // For demonstration, we create a sample account
        Account account = new Account(accountNumber, pin, 1000.00);

        // In a real application, you would verify the account and PIN here

        ATMService atmService = new ATMService(account);
        atmService.start();
    }
}